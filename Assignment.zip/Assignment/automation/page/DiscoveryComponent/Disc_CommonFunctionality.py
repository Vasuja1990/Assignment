"""Module for execution of common portal functionalities such as login, log out, etc
   File: Disc_CommonFunctionality.py
   Author: Vasuja
"""

import os
import sys
import imaplib
import time,re
from collections import defaultdict
import inspect
from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
#For console logs while executing ROBOT scripts
from robot.api.logger import console
from selenium.webdriver.common.keys import Keys

sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__))))
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), "utils"))
#import base
import web_wrappers.selenium_wrappers as base

from log import log
from selenium.webdriver import ActionChains
from mapMgr import mapMgr
mapMgr.create_maplist("Discovery")
mapDict = mapMgr.getMapDict()
mapList = mapMgr.getMapKeyList()

__author__ = "Vasuja"

_RETRY_COUNT = 3

Initial_Login = False


class Disc_CommonFunctionality(object):

    def __init__(self, browser):
        self._browser = browser
        self.action_ele = base.WebElementAction(self._browser)
        self.Initial_Login = False

    def open_url(self, url):
        """
        `Description:` To open Discovery portal.

        `:param` url: URL of Discovery Page

        `:return:`

        `Created by:` Vasuja K
        """
        self._browser.go_to(url)
        log.mjLog.LogReporter("Disc_CommonFunctionality", "info", "Open URL successful")

    def close_browser(self):
        """
        `Description:` Close the browser object

        `:param` driver: WebDriver object

        `:return:``

        `Created by:` Vasuja K
        """
        # time.sleep(2)
        self._browser.quit()
        if self._browser.console_log:
            path = self._browser.console_log.name
            self._browser.console_log.close()
            os.unlink(path)
        self.Initial_Login = False

    def switch_page(self, **params):
        """
        `Description:` To switch to other pages based on given name

        `:param` params: page name which need to be switch

        `:return:`

        `Created by:` Vasuja K
        """
        try:
            print("IN COMMON SWITCH")
            print(params)
            getattr(self, "switch_page_" + params['page'])(params)
        except Exception as err:
            print(err.message)
            self.action_ele.takeScreenshot(inspect.currentframe().f_code.co_name)
            raise Exception("Switch page failed!!")

    def switch_page_see_all_shows(self, *options):
        """
        `Description:` Switch to See All Shows page

        `Param:`  None

        `Returns:` None

        `Created by:` Vasuja K
        """
        self.action_ele.explicit_wait("shows")
        self.action_ele.click_element('shows')
        self.action_ele.explicit_wait("see_all_shows")
        time.sleep(1)
        self.action_ele.mouse_hover('see_all_shows_link')
        self.action_ele.click_element("see_all_shows_link")
        self.action_ele.explicit_wait("tv_shows")

    def switch_page_my_vedios(self, *options):
        """
        `Description:` Switch to See my_vedios

        `Param:`  None

        `Returns:` None

        `Created by:` Vasuja K
        """
        self.action_ele.explicit_wait("dscHeaderMain__hideMobile")
        self.action_ele.click_element('dscHeaderMain__hideMobile')
        self.action_ele.explicit_wait("my_vedios")
        time.sleep(1)
        #self.action_ele.mouse_hover('my_vedios')
        self.action_ele.click_element("my_vedios")
        self.action_ele.explicit_wait("my_vedios_title")